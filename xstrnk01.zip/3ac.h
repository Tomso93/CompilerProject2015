
void genInstr(int InstType, tData *src1, tData *src2, tData *dest, TinstList *list);
void GenNewVariable(string *item);
tData *ReadNameVar(TinstList *list);
