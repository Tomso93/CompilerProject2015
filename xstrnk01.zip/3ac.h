
Tinst *genInstr(int InstType, string *src1, string *src2, string *dest);
void GenNewVariable(string *item);
string *ReadNameVar(TinstList *list);

string *GtableLastDest(globalTS *T, string *id);
