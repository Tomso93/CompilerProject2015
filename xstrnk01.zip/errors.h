/*
 *	errors.h
 *	zpracuje chybu a vypise chybove hlaseni
 *	Autor: Petr Zufan
 *	
 */

void printerror(int errornumber);
