// Header file for lex.c 

void set_source_file(FILE *f);
int getNextToken(string *attr);


