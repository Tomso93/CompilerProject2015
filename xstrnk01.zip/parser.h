#define SYNTAX_OK  48
// hlavicka SA

int parse(tSymbolTable *ST, TinstList *instrList);
