
// hlavicka SA

int parse(tSymbolTable *ST, TinstList *instrList);
